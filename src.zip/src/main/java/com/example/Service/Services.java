package com.example.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import lombok.AllArgsConstructor;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import java.io.File;
import java.io.FileOutputStream;

@Service
public class Services {
    // declare the bucket name

    @Autowired
    private S3Client s3Client;
    @Value("${aws.s3.bucket}")
    private String bucketName;
    @Autowired
    public String uploadFile (MultipartFile file) {
         // create a putobject method to upload the file
         try {
             File fileObj = convertMultiPartFileToFile(file);
             String fileName = System.currentTimeMillis() + "_" + file.getOriginalFilename();
             s3Client.putObject(PutObjectRequest.builder()
             .bucket(bucketName)
             .key(fileName)
             .build(), fileObj);
             fileObj.delete();
         }
         catch (Exception e) {
             e.printStackTrace();
         }
        
         return "file uploaded successfully" + file.getOriginalFilename();
         
    }
 // s3Client.putobject(new PutObjectRequest(bucketName, file.getOriginalFilename(), file));
    private File convertMultiPartFileToFile(MultipartFile file) {
        return null;
    }

}






